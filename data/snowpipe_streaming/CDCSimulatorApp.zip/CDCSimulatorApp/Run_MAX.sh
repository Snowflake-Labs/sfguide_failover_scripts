#!/bin/sh

java -jar CDCSimulatorClient.jar MAX
